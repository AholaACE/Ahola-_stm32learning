#include "pid.h"

void PID_Init(PID_t *pid, float kp, float ki, float kd)
{
    pid->kp = kp;
    pid->ki = ki;
    pid->kd = kd;
    pid->integral = 0;
    pid->last_error = 0;
}

float PID_Update(PID_t *pid, float target, float feedback)
{
    float err = target - feedback;
    pid->integral += err;
    float der = err - pid->last_error;
    pid->last_error = err;

    return pid->kp * err + pid->ki * pid->integral + pid->kd * der;
}
