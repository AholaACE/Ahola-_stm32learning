#ifndef __TIMER_H
#define __TIMER_H
void TIM_Init(void);
#endif
