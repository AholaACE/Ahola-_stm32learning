#ifndef __CAN_H
#define __CAN_H
#include "stm32f10x.h"

void my_can1_init(void);
void CAN1_Send(int a, int b, int c, int d);

#endif
