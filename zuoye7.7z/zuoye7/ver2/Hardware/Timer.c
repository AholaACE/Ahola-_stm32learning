#include "Timer.h"
#include "stm32f10x.h"
#include "serial.h"
#include "pid.h"
#include "M3508.h"
#include <math.h>

extern PID_t speed_pid;
extern M3508_t motor1;

void TIM_Init(void)
{
    TIM_TimeBaseInitTypeDef tim;
    NVIC_InitTypeDef nvic;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

    tim.TIM_Prescaler = 7199;   // 72MHz / 7200 = 10kHz
    tim.TIM_Period    = 99;     // 10kHz / 100 = 100Hz
    tim.TIM_CounterMode = TIM_CounterMode_Up;
    tim.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInit(TIM3, &tim);

    TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);

    nvic.NVIC_IRQChannel = TIM3_IRQn;
    nvic.NVIC_IRQChannelCmd = ENABLE;
    nvic.NVIC_IRQChannelPreemptionPriority = 0;
    nvic.NVIC_IRQChannelSubPriority = 0;
    NVIC_Init(&nvic);

    TIM_Cmd(TIM3, ENABLE);
}

void TIM3_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
    {
        TIM_ClearITPendingBit(TIM3, TIM_IT_Update);

        static float t = 0.0f;
        t += 0.05f;

        // ===== ��������Ŀ���ٶȣ�ʾ�����ң�=====
        float target_rpm = 120.0f + 40.0f * sinf(t);

        // ===== ʵ���ٶȣ�û�ӵ������ 0��=====
        float actual_rpm = motor1.speed_rpm_f;

        // ===== PID =====
        float out = PID_Update(&speed_pid, target_rpm, actual_rpm);

        if (out > 16000) out = 16000;
        if (out < -16000) out = -16000;

        M3508_SetCurrent((int16_t)out);

        // ===== FireWater ������� =====
        VOFA_Send_FireWater(target_rpm, actual_rpm);
    }
}
