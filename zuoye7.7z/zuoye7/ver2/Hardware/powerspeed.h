#ifndef __POWERSPEED_H
#define __POWERSPEED_H

float PowerSpeed_Update(float dt);
void  PowerSpeed_InitRandom(void);

#endif
