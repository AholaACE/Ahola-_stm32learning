#include "M3508.h"
#include "CAN.h"

M3508_t motor1;

void M3508_Init(void)
{
    motor1.speed_rpm_f = 0.0f;
    motor1.current_out = 0;
}

void M3508_SetCurrent(int16_t iq)
{
    motor1.current_out = iq;
    CAN1_Send(iq, 0, 0, 0);
}

void M3508_CAN1_Receive(CanRxMsg *msg)
{
    if (msg->StdId == 0x201)
    {
        int16_t raw = (msg->Data[2] << 8) | msg->Data[3];
        motor1.speed_rpm_f = raw / 100.0f;
    }
}
