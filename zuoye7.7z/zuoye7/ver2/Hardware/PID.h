#ifndef __PID_H
#define __PID_H

typedef struct {
    float kp, ki, kd;
    float error;
    float last_error;
    float integral;
} PID_t;

void  PID_Init(PID_t *pid, float kp, float ki, float kd);
float PID_Update(PID_t *pid, float target, float feedback);

#endif
