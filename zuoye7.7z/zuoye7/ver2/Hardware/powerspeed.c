#include "powerspeed.h"
#include <math.h>
#include <stdlib.h>

static float t = 0;
static float a = 0.9f;
static float w = 1.95f;
static float b = 1.19f;  // = 2.09 - a

void PowerSpeed_InitRandom(void)
{
    a = 0.78f + ((float)(rand() % 1000) / 1000.0f) * (1.045f - 0.78f);
    w = 1.884f + ((float)(rand() % 1000) / 1000.0f) * (2.000f - 1.884f);
    b = 2.090f - a;
    t = 0;
}

float PowerSpeed_Update(float dt)
{
    t += dt;
    return a * sinf(w * t) + b;   // rad/s
}
