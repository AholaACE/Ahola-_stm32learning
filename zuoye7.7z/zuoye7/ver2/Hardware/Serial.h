#ifndef __SERIAL_H
#define __SERIAL_H
#include "stm32f10x.h"

void Serial_Init(void);
void Serial_SendByte(uint8_t Byte);
void Serial_SendArray(uint8_t *Array, uint16_t Length);
void VOFA_Send_JustFloat(float target, float actual);

#endif
