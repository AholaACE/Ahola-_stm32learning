#include "m3508.h"
#include "pid.h"
#include "mycan.h"
#include "serial.h"
#include <math.h>

#define REDUCTION_RATIO 19.2032f    // M3508减速比
#define PI_VALUE        3.1415926f

#define CURRENT_LIMIT   5000.0

// a = 0.9125, w = 1.942, b = 2.090 - a = 1.1775
#define RUNE_A          0.9125
#define RUNE_W          1.942
#define RUNE_B          1.1775

PID_TypeDef speed_pid;

static float ctrl_time = 0.0f;
static uint8_t vofa_div = 0;



void M3508_Init(void)
{
    PID_Init(&speed_pid, 6.0, 0.15, 0.0, 2000.0, CURRENT_LIMIT);
}


void M3508_Control(void)
{
    float target_rad_s; // 目标输出轴角速度 (rad/s)
    float target_rpm;   // 目标电机转子转速 (RPM)
    float feedback_rpm; // 实际电机转子转速 (RPM)
    float output_current;

    //大符速度
    target_rad_s = RUNE_A * sinf(RUNE_W * ctrl_time) + RUNE_B;

    //单位换算: 输出轴(rad/s) -> 转子(RPM)
    //转子RPM = 输出轴rad/s * (60 / 2π) * 减速比
    target_rpm = target_rad_s * (60.0f / (2.0f * PI_VALUE)) * REDUCTION_RATIO;

    //取反馈速度
    feedback_rpm = (float)M3508_Feedback.speed_rpm;

    //PID计算
    output_current = PID_Calc(&speed_pid, target_rpm, feedback_rpm);

    if (output_current > CURRENT_LIMIT) output_current = CURRENT_LIMIT;
    if (output_current < -CURRENT_LIMIT) output_current = -CURRENT_LIMIT;

    CAN_Send_Current((int16_t)output_current);
    vofa_div++;
    if (vofa_div >= 10) 
    {
        vofa_div = 0;
        float feedback_rad_s = feedback_rpm / REDUCTION_RATIO * (2.0f * PI_VALUE / 60.0f);
        
        VOFA_Send_JustFloat(target_rad_s, feedback_rad_s);
    }

    ctrl_time += 0.001;
}
