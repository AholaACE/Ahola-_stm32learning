// pid.h
#ifndef __PID_H
#define __PID_H

typedef struct
{
    float kp, ki, kd;
    float err, last_err;
    float pout, iout, dout;
    float max_i, max_out;
} PID_TypeDef;

void PID_Init(PID_TypeDef *pid, float kp, float ki, float kd, float max_i, float max_out);
float PID_Calc(PID_TypeDef *pid, float ref, float fdb);

#endif
