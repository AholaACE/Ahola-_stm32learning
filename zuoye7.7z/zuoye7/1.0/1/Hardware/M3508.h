#ifndef __M3508_H__
#define __M3508_H__

void M3508_Init(void);
void M3508_Control(void); // 1ms ����һ��

#endif
