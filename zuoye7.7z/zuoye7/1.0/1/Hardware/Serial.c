#include "serial.h"

static void SendByte(uint8_t b)
{
    USART_SendData(USART1, b);
    while(USART_GetFlagStatus(USART1, USART_FLAG_TXE)==RESET);
}

void Serial_Init(void)
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1|RCC_APB2Periph_GPIOA, ENABLE);

    GPIO_InitTypeDef g;
    g.GPIO_Pin = GPIO_Pin_9; // TX
    g.GPIO_Mode = GPIO_Mode_AF_PP;
    g.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &g);

    g.GPIO_Pin = GPIO_Pin_10; // RX
    g.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &g);

    USART_InitTypeDef u;
    u.USART_BaudRate = 115200; // ���� 115200
    u.USART_WordLength = USART_WordLength_8b;
    u.USART_StopBits = USART_StopBits_1;
    u.USART_Parity = USART_Parity_No;
    u.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    u.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    
    USART_Init(USART1, &u);
    USART_Cmd(USART1, ENABLE);
}

void VOFA_Send_JustFloat(float a, float b)
{
    uint8_t *p;

    // ����Ŀ��ֵ
    p=(uint8_t*)&a;
    for(int i=0;i<4;i++) SendByte(p[i]);

    // ����ʵ��ֵ
    p=(uint8_t*)&b;
    for(int i=0;i<4;i++) SendByte(p[i]);

    // ����֡β 00 00 80 7F
    SendByte(0x00);
    SendByte(0x00);
    SendByte(0x80);
    SendByte(0x7F);
}
