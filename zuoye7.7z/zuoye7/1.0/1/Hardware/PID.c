#include "pid.h"
#define PID_DT 0.001

void PID_Init(PID_TypeDef *pid, float kp, float ki, float kd, float max_i, float max_out)
{
    pid->kp = kp;
    pid->ki = ki;
    pid->kd = kd;
    pid->max_i = max_i;
    pid->max_out = max_out;
    pid->err = pid->last_err = 0;
    pid->iout = 0;
}

float PID_Calc(PID_TypeDef *pid, float ref, float fdb)
{
    pid->err = ref - fdb;

    pid->pout = pid->kp * pid->err;

    pid->iout += pid->ki * pid->err * PID_DT;
    if(pid->iout > pid->max_i) pid->iout = pid->max_i;
    else if(pid->iout < -pid->max_i) pid->iout = -pid->max_i;

    pid->dout = pid->kd * (pid->err - pid->last_err) / PID_DT;
    pid->last_err = pid->err;

    float out = pid->pout + pid->iout + pid->dout;
    if(out > pid->max_out) out = pid->max_out;
    else if(out < -pid->max_out) out = -pid->max_out;

    return out;
}
