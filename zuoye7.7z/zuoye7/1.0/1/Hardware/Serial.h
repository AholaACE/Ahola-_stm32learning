#ifndef __SERIAL_H__
#define __SERIAL_H__

#include "stm32f10x.h"

void Serial_Init(void);
void VOFA_Send_JustFloat(float a, float b);

#endif
