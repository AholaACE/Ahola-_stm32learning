#ifndef __MYCAN_H__
#define __MYCAN_H__

#include "stm32f10x.h"

typedef struct
{
    uint16_t angle;
    int16_t  speed_rpm;
    int16_t  real_current;
    uint8_t  temperature;
} M3508_TypeDef;

extern M3508_TypeDef M3508_Feedback;

void CAN1_Init(void);
void CAN_Send_Current(int16_t current);

#endif
