#include "stm32f10x.h"                  // Device header

#include "mycan.h"
#include "serial.h"
#include "timer.h"
#include "m3508.h"

int main(void)
{	

    Serial_Init();
    CAN1_Init();
    TIM2_Init();
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    M3508_Init();

    while(1)
    {
	
    }
}
