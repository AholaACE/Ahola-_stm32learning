#include "heat.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "delay.h"

Heat_TypeDef heat_system;
static Heat_TypeDef* p;

void HeatInit(void)
{
    Key_Init();
    LED_Init();
    
    p = &heat_system;
    
    p->now_heat = 0;
    p->lock = 0;
}

void update(void)
{
    static uint32_t count = 0;
    static uint8_t key = 1;
    static uint8_t fire = 0;
    static uint32_t count1 = 0;
    static uint32_t coolcount = 0;
    
    uint8_t nowkey = Key_Option();
    

    if (nowkey == 0) { // 按下
        if (key == 1) {
            count = 0;
            key = 0;
        }
        
        count++;
        
        // 长按
        if (count > 50) {
            fire = 1;
        }
    } else { // 按键释放
        if (key == 0) {
            // 短按,不知道为啥实现不了
            if (count > 0 && count <= 50) {
                if (!p->lock) {
                    Add(10);
                }
            }
            fire = 0;
            key = 1;
            count = 0;
        }
    }
    
    // 连发
    if (fire && !p->lock) {
        count1++;
        if (count1 >= 5) {
            Add(10);
            count1 = 0;
        }
    } else {
        count1 = 0;
    }
    
    // 冷que
    coolcount++;
    if (coolcount >= 10) {
        cool();
        coolcount = 0;
    }
    
    LED_Option(p->now_heat, p->lock, 0);
}

void Add(uint16_t heat)
{
    if (p->lock) {
        return;
    }
    
    if (p->now_heat + heat <= 0xFFFF) {
        p->now_heat += heat;
    } else {
        p->now_heat = 0xFFFF;
    }
    
    if (p->now_heat > 190) {
        p->lock = 1;
    }
}

void cool(void)
{
    if (p->now_heat > 0) {
        if (p->now_heat >= 9) {
            p->now_heat -= 9;
        } else {
            p->now_heat = 0;
        }
    }
    
    if (p->now_heat == 0) {
        p->lock = 0;
    }
}

uint16_t nowheat(void)
{
    return p->now_heat;
}

uint8_t open(void)
{
    return !p->lock;
}
