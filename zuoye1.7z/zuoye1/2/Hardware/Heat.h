#ifndef __HEAT_H
#define __HEAT_H

#include "stm32f10x.h"
#include "key.h"
#include "led.h"

typedef struct {
    uint16_t now_heat;
    uint8_t lock;
} Heat_TypeDef;

void HeatInit(void);
void update(void);
void Add(uint16_t heat);
void cool(void);
uint16_t nowheat(void);
uint8_t open(void);

#endif
