#include "led.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"


void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
	
    LED_OFF();
}

void LED_Option(uint16_t heat, uint8_t lock, uint32_t system_time_ms)
{

     if (lock) 
	{
        LED_ON();
        return;
    }
    
    // 计算热量百分比
    uint32_t percent;
    if (heat > 190) {
        percent = 100; 
    } else {
        percent = (heat * 100) / 190;
    }
    
	//计算
    uint8_t lightLED = percent / 10;
    if (lightLED > 10) lightLED = 10;
    

    LED_OFF();
    
    if (lightLED >= 1) GPIO_SetBits(GPIOA, GPIO_Pin_0);
    if (lightLED >= 2) GPIO_SetBits(GPIOA, GPIO_Pin_1);
    if (lightLED >= 3) GPIO_SetBits(GPIOA, GPIO_Pin_2);
    if (lightLED >= 4) GPIO_SetBits(GPIOA, GPIO_Pin_3);
    if (lightLED >= 5) GPIO_SetBits(GPIOA, GPIO_Pin_4);
    if (lightLED >= 6) GPIO_SetBits(GPIOA, GPIO_Pin_5);
    if (lightLED >= 7) GPIO_SetBits(GPIOA, GPIO_Pin_6);
    if (lightLED >= 8) GPIO_SetBits(GPIOA, GPIO_Pin_7);
    if (lightLED >= 9) GPIO_SetBits(GPIOA, GPIO_Pin_8);
    if (lightLED >= 10) GPIO_SetBits(GPIOA, GPIO_Pin_9);
}

void LED_OFF(void)
{
    GPIO_ResetBits(GPIOA, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | 
                          GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7 |
                          GPIO_Pin_8 | GPIO_Pin_9);
}

void LED_ON(void)
{
    GPIO_SetBits(GPIOA, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | 
                          GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7 |
                          GPIO_Pin_8 | GPIO_Pin_9);
}
