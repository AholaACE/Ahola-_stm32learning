//heat借助了AI帮我完成想法，但是单发还是不知道咋实现，写了一下不行，
//这里主函数不知道为什么一直说我未定义，但是又不报错
//数据定义的部分是AI教我的，数据类型还是有点没懂，正在B站看视频^^
//还有就是每个文件最后一行都要留，这个经常报错
#include "stm32f10x.h"
#include "heat.h"
#include "delay.h"
#include "led.h"

int main(void)
{
    HeatInit();
    
    while(1)
    {
        update();
        Delay_ms(10);

    }
}

