///*热量上限190，1s冷却10次，1次9，每秒90，每次每发射弹丸热量+10*/'
#ifndef __HEAT_H
#define __HEAT_H

uin8_t Heat;


#endif