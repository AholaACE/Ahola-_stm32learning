#include "stm32f10x.h"                  // Device header
#ifndef __LED_H
#define __LED_H

void LED_Init(void);
void LED_SYSTEM(uint8_t heat);

#endif
