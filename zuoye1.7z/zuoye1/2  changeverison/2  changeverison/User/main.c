#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "Heat.h"
#include "LED.h"
#include "Key.h"
#include "OLED.h"
#include "Timer.h"

uint8_t Heat = 0;


int main()
{
	LED_Init();
	OLED_Init(); 
	Key_Init(); 

	
	 // 冷却计数器
    uint16_t coolcounter = 0;
    // 长按连发计数器
    uint16_t long_counter = 0;
    // 长按状态标志
    uint8_t iflongkey = 0;
	
	OLED_ShowString(1,3,"Heat:");
	OLED_ShowNum(1, 8, Heat, 3);
	
	while(1)
	{
		Key_Tick(); 
		
		if (Key_Check(0, KEY_SINGLE))
		{
			if (Heat <= 180) 
			{
                Heat = Heat + 10; 
                
            }
			if(Heat > 190)
			{
				Heat = 190;
			}
			LED_SYSTEM(Heat);
            OLED_ShowNum(1, 8, Heat, 3);
		} 
		
		if (Key_Check(0,KEY_REPEAT))
		{ 
			  if (Heat <= 190) 
			{
                Heat = Heat + 10; 
                
            }		
			LED_SYSTEM(Heat);
            OLED_ShowNum(1, 8, Heat, 3);
		} 
		
		coolcounter++;
        if (coolcounter >= 100) 
        {
            // 每秒冷却9
            if (Heat >= 9) 
			{
                Heat = Heat - 9;
            } else 
			{
                Heat = 0;
            }
            
            LED_SYSTEM(Heat);
            OLED_ShowNum(1, 8, Heat, 3);
	
            coolcounter = 0;
        }
        
   
        if (Heat >= 190) 
		{
            Heat = 190;
            LED_SYSTEM(Heat);
            OLED_ShowNum(1, 8, Heat, 3);
        }
        
        Delay_ms(10);
	}
	
	
}
